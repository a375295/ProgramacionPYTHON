
import sys
import time

import pygame

import generador
from buttons.btns import Button, Button1

# Inicializar el modulo pygame
screen = pygame.display.set_mode((1010, 650))
pygame.font.init()
pygame.mixer.init()
sound_correct = pygame.mixer.Sound("sounds/correct.mp3")
sound_timeup = pygame.mixer.Sound("sounds/timeup.mp3")
sound_win = pygame.mixer.Sound("sounds/victory.mp3")

# Fondo del juego
bg_game = pygame.image.load("assets/fondo2.jpeg")
bg_game = pygame.transform.scale(bg_game, (1010, 650))

# Fondo cuando pierden
bg_timeup = pygame.image.load("assets/gary.jpeg")
bg_timeup = pygame.transform.scale(bg_timeup, (1010, 650))

# Fondo cuando ganen
bg_win = pygame.image.load("assets/win.jpeg")
bg_win = pygame.transform.scale(bg_win, (1010, 650))
# lista vacia para almacenar las coordenadas de las celdas seleccionadas
seleccionado = []

arrastrar = False  # Para indicar si el usuario esta arrastrando el mouse sobr la tabla
adivinar = []  # para almacenar las palabras adivinadas por el usuario
palabra = ""  # para almacenar la palabra en construccion mientras que el usuario arrastra el mouse sobre la tabla
ejecutando = True  # para controlar el ciclo principal del juego
game_over = False
adivinar_indexes = []
start_time = time.time()
elapsed_time = 0
sound_played = False
cronometro_activo = False

def salir():
    pygame.quit()
    sys.exit()

def reiniciar_juego():
    global start_time, elapsed_time, arrastrar, palabra, adivinar_indexes, words_adivinadas, seleccionado, sound_played
    sound_played = False
    start_time = time.time()
    elapsed_time = 0
    arrastrar = False
    palabra = ""
    seleccionado = []
    adivinar_indexes = []
    palabras = generador.generador_palabras([])
    palabras_cpy=palabras[::]
    words_adivinadas = refinar_lista(palabras_cpy[::])
    print(palabras)
    grid=[] # nos representa la matriz 
    alfabeto="ABCDFEFGHIJKLMNOPQRSTUVWXYZ" 
    alfabeto=list(alfabeto)
    for i in range(15):
        grid.append(list("0"*15))
    generador.generar_sopa(palabras, grid, alfabeto)
    inicializar(palabras_cpy, grid)

    
button_salir = Button(350, 400, 100, 50, "Leave", action=salir)
button_reiniciar = Button(500, 400, 140, 50, "Play again", action= reiniciar_juego)

# Muestra la pantalla si la lista list_copy esta vacia nos resalta la pantalla si ganastes
def pantalla_final(pantalla, list_copy, game_over):
    global event, sound_played, cronometro_activo
    pygame.font.init()
    gamef_formato = pygame.font.Font("Quicksilver.ttf", 100)
    if list_copy == []:
        pantalla.fill((255, 255, 255))
        cronometro_activo = False
        screen.blit(bg_win, (0,0))
        mostrar_palabra = gamef_formato.render("YOU WON", True, "Blue")
        palabra_ancho = mostrar_palabra.get_width()
        palabra_alto = mostrar_palabra.get_height()
        x = (screen.get_width() - palabra_ancho) // 2
        y = (screen.get_height() - palabra_alto) // 2
        pantalla.blit(mostrar_palabra, (x, y))
        button_salir.handle_event(event)
        button_salir.draw(screen)
        button_reiniciar.handle_event(event)
        button_reiniciar.draw(screen)
    if game_over:
        pantalla.fill((255, 255, 255))
        screen.blit(bg_timeup, (0,0))
        mostrar_palabra = gamef_formato.render("TIME'S UP", True, "Red")
        palabra_ancho = mostrar_palabra.get_width()
        palabra_alto = mostrar_palabra.get_height()
        x = (screen.get_width() - palabra_ancho) // 2
        y = (screen.get_height() - palabra_alto) // 2
        pantalla.blit(mostrar_palabra, (x, y))  
        button_salir.handle_event(event)
        button_salir.draw(screen)
        button_reiniciar.handle_event(event)
        button_reiniciar.draw(screen)


# Recibimos la palabra y eliminamos caracteres duplicados consecutivos y nos devuelve la palabra sin duplicados
def remover_duplicado(palabra):
    try:
        s = ""
        s += palabra[0]
        for i in range(1, len(palabra)):
            if palabra[i] != s[-1]:
                s += palabra[i]
        return s
    except IndexError:
        return 0


# Recibimos la lista y eliminamos duplicados en cada elemento de la lista, con la funcion de remove_duplicate
def refinar_lista(lst):
    for i in range(len(lst)):
        lst[i] = remover_duplicado(lst[i])
    return lst

words_adivinadas = refinar_lista(generador.palabras_cpy[::]) # :: para crear copias de listas

# Nos dibuja en el tablero de juego en la pantalla. Utilizamos la libreria pygame.draw.rect
# para dibujar los rectangulos que representan las celdas del tablero
def tablero():
    x_start = 0
    y_start = 0
    for i in range(15):
        for j in range(15):
            if [x_start, y_start] in adivinar_indexes:
                if is_horizontal_o_vert(adivinar_indexes):
                    pygame.draw.rect(screen, "blue", (x_start, y_start, 40, 40), 0)
                else:
                    pygame.draw.rect(screen, "white", (x_start, y_start, 40, 40), 1)
            elif [x_start, y_start] in seleccionado:
                pygame.draw.rect(screen, "green", (x_start, y_start, 40, 40), 0)
                pygame.draw.rect(screen, "white", (x_start, y_start, 40, 40), 1)
            else:
                pygame.draw.rect(screen, "white", (x_start, y_start, 40, 40), 1)
            x_start += 40
        x_start = 0
        y_start += 40

def is_horizontal_o_vert(coordenadas):
    x_value = [x for x, _ in coordenadas]
    y_value = [y for _, y in coordenadas]
    return len(set(x_value)) == 1 or len(set(y_value)) == 1

# Nos muestra las palabras del juego en la pantalla. Utilizamos la libreria pygame.font para renderizar el texto en la posicion adecuada
def buscar_imprimir(grid):
    y = 25
    buscar_formato = pygame.font.Font("Quicksilver.ttf", 30)
    for line in grid:
        x = 21
        for i in range(15):
            search_render = buscar_formato.render(line[i].upper(), True, (0, 0, 0))
            width = search_render.get_width()
            height = search_render.get_height()

            screen.blit(search_render, (x - width // 2, y - height // 2))
            x += 40
        y += 40

# Nos muestra las palabras restantes para adivinar en la pantalla,
# igual usamos pygame.font para renderizar el texto en la posicion adecuada
def mostrar_palabras(palabras_cpy):
    x = 670
    y = 80
    word_formato = pygame.font.Font("freesansbold.ttf", 25)
    words_titulo_formato = pygame.font.Font("Quicksilver.ttf", 35)

    title_words = words_titulo_formato.render("PRESENT VERBS", True, (0, 0, 255))
    screen.blit(title_words, (x, 25))
    for word in palabras_cpy:
        mostrar_word = word_formato.render(word, True, (0, 0, 0))
        screen.blit(mostrar_word, (x, y))
        y += 33

def mostrar_cronometro():
        # calculamos
        minutos_restantes = int((1 * 180 - elapsed_time) // 60)
        segundos_restantes = int((1 * 180 - elapsed_time) % 60)

        # Formateamos el texto del tiempo
        tiempo_restante = f"Time: {minutos_restantes:02d}:{segundos_restantes:02d}"

        if cronometro_activo:
            cronometro_formato = pygame.font.Font("Quicksilver.ttf", 30)
            cronometro_render = cronometro_formato.render(tiempo_restante, True, (0, 0, 0))
            screen.blit(cronometro_render, (670, 510))

def inicializar(palabras_cpy, grid):
    global ejecutando, screen, arrastrar, adivinar_indexes, event, sound_played, palabra, words_adivinadas, seleccionado, cronometro_activo, current_time, start_time, elapsed_time
    while ejecutando:
        
        screen.fill((255, 255, 255))
        screen.blit(bg_game, (0,0))
        tablero()
        mostrar_palabras(palabras_cpy)
        buscar_imprimir(grid)
        cronometro_activo = True
        current_time = time.time()
        elapsed_time = current_time - start_time

        if elapsed_time >= 180:
            cronometro_activo = False
        mostrar_cronometro()
        
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                ejecutando = False
                pygame.quit()
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                arrastrar = True
                x, y = pygame.mouse.get_pos()
                if x <= 600:
                    palabra += grid[(y // 40 % 15)][(x // 40) % 15]
                if 450 <= event.pos[0] <= 550 and 300 <= event.pos[1] <= 350:
                    salir()
            elif event.type == pygame.MOUSEMOTION and arrastrar:
                x, y = pygame.mouse.get_pos()
                if x <= 600:
                    palabra += grid[(y // 40 % 15)][(x // 40) % 15]
                    adivinar_indexes.append([x // 40 * 40, y // 40 * 40])
            elif event.type == pygame.MOUSEBUTTONUP:
                arrastrar = False
                if remover_duplicado(palabra) in words_adivinadas:
                    seleccionado += adivinar_indexes
                    index = words_adivinadas.index(remover_duplicado(palabra))
                    words_adivinadas.remove(remover_duplicado(palabra))
                    palabras_cpy.pop(index)
                    sound_correct.play()
                palabra = ""
                adivinar_indexes = []
        if words_adivinadas == []:
            if not sound_played:
                sound_win.play()
                sound_played = True
            game_over = False
            pantalla_final(screen, words_adivinadas, game_over)
        if elapsed_time >= 180:
            if not sound_played:
                sound_timeup.play()
                sound_played = True
            game_over = True
            pantalla_final(screen, words_adivinadas, game_over)      
        pygame.display.flip()


def get_font(size):
    return pygame.font.Font("Quicksilver.ttf", size)

def main_menu():
    global elapsed_time, start_time
    screen = pygame.display.set_mode((1010, 650))
    pygame.display.set_caption("Word Soup")
    icon = pygame.image.load("icon/icono_sopa.ico")
    pygame.display.set_icon(icon)
    bg = pygame.image.load("assets/Background.png")
    while True:
        screen.blit(bg, (0,0))
        bg = pygame.transform.scale(bg, (1010, 650))

        menu_mouse_pos = pygame.mouse.get_pos()

        mt1 = get_font(170).render("WORD", True, "#FF00FF")
        mr1 = mt1.get_rect(center=(500, 90))

        mt1_2 = get_font(170).render("WORD", True, "#00fffe")
        mr1_2 = mt1_2.get_rect(center=(512, 95))

        mt1_3 = get_font(170).render("WORD", True, "#8c53fe")
        mr1_3 = mt1_3.get_rect(center=(504, 95))

        ###

        mt2 = get_font(120).render("SOUP", True, "#FF00FF")
        mr2 = mt2.get_rect(center=(500, 210))

        mt2_2 = get_font(120).render("SOUP", True, "#00fffe")
        mr2_2 = mt2_2.get_rect(center=(512, 215))

        mt2_3 = get_font(120).render("SOUP", True, "#8c53fe")
        mr2_3 = mt2_3.get_rect(center=(504, 215))

        play_button = Button1(image=pygame.image.load("assets/Play Rect.png"), pos=(500, 400),
                              text_input="PLAY", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        quit_boton = Button1(image=pygame.image.load("assets/Quit Rect.png"), pos=(500, 550),
                             text_input="QUIT", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        
        screen.blit(mt1, mr1)
        screen.blit(mt1_2, mr1_2)
        screen.blit(mt1_3, mr1_3)
        screen.blit(mt2, mr2)
        screen.blit(mt2_2, mr2_2)
        screen.blit(mt2_3, mr2_3)

        for button in [play_button, quit_boton]:
            button.changeColor(menu_mouse_pos)
            button.update(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.checkForInput(menu_mouse_pos):
                    start_time = time.time()
                    elapsed_time = 0
                    inicializar(generador.palabras_cpy, generador.grid)
                if quit_boton.checkForInput(menu_mouse_pos):
                    pygame.quit()
                    sys.exit()
        pygame.display.update()

main_menu()
