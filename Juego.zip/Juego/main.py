import sys
import time
import pygame
import generador
from tabla import inicializar, start_time, elapsed_time
from buttons.btns import Button1
pygame.init()

