import random


# leemos el archivo y agregamos las palabras a la lista  y nos retorna la lista de palabras
def generar_lst_palabras():
    file = open("palabras.txt", "r")
    lst_palabras = []
    for line in file.readlines():
        lst_palabras.append(line.rstrip())
    return lst_palabras

# verificamos si una palabra puede ser colocada en una posicion especifica en la matriz de la sopa
def verificar_posib(matriz,palabra,index,ordenes_indicadas,orden_indicado):
    x,y=index
    ix,iy=ordenes_indicadas[orden_indicado]
    try:
        for i in range(len(palabra)):
            if 0<=y<=14 and 0<=x<=14:
                if matriz[y][x]!="0":
                    return False
                x+=ix
                y+=iy
            else :
                return False
    except IndexError:
        return False

    return True

# Colocamos una palabra en la matriz en una posicion especifica
def colocar_palabra(matriz,palabra,index,ordenes_indicadas,orden_indicado):
    x,y=index
    ix,iy=ordenes_indicadas[orden_indicado]
    for _ in range(len(palabra)):
        matriz[y][x]=palabra[_]
        y+=iy
        x+=ix

# Nos genera 10 palabras aleatorias seleccionadas de la lista de palabras lst_words. 
# Estas mismas se agregan a la lista words y se eliminan de la lista lst_words
def generador_palabras(palabras):
    for i in range(10): 
        palabra_rndm=random.choice(lst_palabras)
        palabras.append(palabra_rndm)
        lst_palabras.remove(palabra_rndm)
    return palabras


grid=[] # nos representa la matriz 
alfabeto="ABCDFEFGHIJKLMNOPQRSTUVWXYZ" 
alfabeto=list(alfabeto)
for i in range(15):
    grid.append(list("0"*15))
lst_palabras=generar_lst_palabras() # lista almacena las palabras obtenidas
palabras=generador_palabras([]) # lista que nos servira para almacenar las palabras seleccionadas para colocar en la matriz
palabras_cpy=palabras[::] # hacemos una copia de la lista words

# diccionario que mapea cada direccion de movimiento a un par de coordenadas x y
# ejemplo: si f esta puesto a (1,0) quiere decir que se debe desplazar una posicion hacia la derecha en el eje x,  y mantener el mismo valor en el eje y
pisibilidades={"f":(1,0),"b":(-1,0),"u":(0,-1),"d":(0,1)}
movimiento=["f","b","u","d"] # direcciones posibles para colocar las palabras, adelante ("f"), atrás ("b"), arriba ("u") y abajo ("d")

def generar_sopa(palabras, grid, alfabeto):
    while(True):
        if palabras==[]:
            break
        # se selecciona aleatorio una palabra de la lista words y se elimina de la lista
        palabra=random.choice(palabras)
        palabras.remove(palabra)
        # generamos las coordenadas aleatorias para la posicion inicial de la palabra
        x_coordenada=random.randint(0,14)
        y_coordenada=random.randint(0,14)
        index=(x_coordenada,y_coordenada)
        # seleccionamos aleatoria una direccion para colocar la palabra
        direccion=random.choice(movimiento)
        # aqui verificamos si es posible colocar la palabra en la posicion y direccion especificadas
        while(verificar_posib(grid,palabra,index,pisibilidades,direccion)!=1):
            x_coordenada=random.randint(0,14)
            y_coordenada=random.randint(0,14)
            index=(x_coordenada,y_coordenada)
        colocar_palabra(grid,palabra,index,pisibilidades,direccion) # mandamos los parametros
    # rellenamos con una letra de la lista alphabet, si una parte de la matriz es 0 
    for i in range(15):
        for j in range(15):
            if grid[i][j]=="0":
                grid[i][j]=random.choice(alfabeto)
# generamos la sopa de letras

generar_sopa(palabras, grid, alfabeto)
