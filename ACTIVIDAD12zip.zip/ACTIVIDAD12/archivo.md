|   Id | Ap.Paterno   | Ap.Materno   | Nombre    | Puesto     | Sexo   |
|-----:|:-------------|:-------------|:----------|:-----------|:-------|
|   31 | Leyva        | Zambrano     | César     | Encargad@  | HOMBRE |
|   32 | Galindo      | Galindo      | Emilio    | Encargad@  | HOMBRE |
|   33 | Cruz         | Murrieta     | Federico  | Supervisor | HOMBRE |
|   34 | Encinas      | Perez        | Alejandro | Conserje   | HOMBRE |
|   35 | Yepiz        | Cruz         | Ana       | Jefe       | MUJER  |
|   36 | Martinez     | Cardenas     | Martina   | Supervisor | MUJER  |
|   37 | Romero       | Hidalgo      | Laura     | Gerente    | MUJER  |
|   38 | Morro        | Contreras    | Carla     | Encargad@  | MUJER  |
|   39 | Zambrano     | Romero       | Carolina  | Gerente    | MUJER  |
|   40 | Cruz         | Galindo      | Emilio    | Guardia    | HOMBRE |